package wk.fom.fyl.iteration1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

@RestController
public class I01Controller {
	@Autowired
	private I01Service i01Service;
	
	@GetMapping("/mapi/v1/myproject/{projectId}/catalogs")
	public @ResponseBody JsonNode getProjectCatalogList(
			@RequestHeader HttpHeaders headers,
			@PathVariable("projectId") String projectId) {
		return i01Service.run(headers, projectId);
	}
}
