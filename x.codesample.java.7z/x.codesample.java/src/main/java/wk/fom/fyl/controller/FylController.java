package wk.fom.fyl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import wk.fom.fyl.service.GatProjectCatalogListService;

@RestController
public class FylController {
	@Autowired
	private GatProjectCatalogListService getProjectCatalogListService;
	
	
	
	@GetMapping("/mapi/v2/myproject/{projectId}/catalogs")
	public @ResponseBody String getProjectCatalogList(
			@RequestHeader HttpHeaders headers,
			@PathVariable("projectId") String projectId) {
		return getProjectCatalogListService.run(headers, projectId);
	}
}
