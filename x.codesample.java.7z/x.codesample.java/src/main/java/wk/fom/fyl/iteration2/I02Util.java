package wk.fom.fyl.iteration2;

import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.JsonPath;

public class I02Util {
	public static ObjectNode makeNormalTaskData(ObjectNode parent, String taskName) {
		ObjectNode node = parent.objectNode();
		ObjectNode input = parent.objectNode();
		ObjectNode output = parent.objectNode();
		input.set("header", parent.objectNode());
		input.set("path", parent.objectNode());
		input.set("param", parent.objectNode());
		input.set("body", parent.objectNode());
		node.set("input", input);
		output.set("header", parent.objectNode());
		output.set("body", parent.objectNode());
		node.set("output", output);
		parent.set(taskName, node);
		return node;
	}
	
	public static ObjectNode makeLoopTaskData(ObjectNode parent, String taskName) {
		ObjectNode node = parent.objectNode();
		ObjectNode output = parent.objectNode();
		output.set("header", parent.objectNode());
		output.set("body", parent.objectNode());
		node.set("output", output);
		parent.set(taskName, node);
		return node;
	}
	
	public static void setHeaderJson(ObjectNode parent, String path, HttpHeaders header) {
		ObjectNode node = JsonPath.read(parent, path);
		for(Entry<String, List<String>> e : header.entrySet()) {
			if( e.getValue().size() > 1 ) {
				ArrayNode va = parent.arrayNode();
				for( String str : e.getValue() ) {
					va.add(str);
				}
				node.set(e.getKey(), va);
				
			} else {
				node.put(e.getKey(), e.getValue().get(0));
			}
		}
	}
	
	public static HttpStatus callRestApi(String uri, ObjectNode currNode, HttpMethod method) {

		HttpHeaders hdr = new HttpHeaders();
		ObjectNode tmp = JsonPath.read(currNode, "$.input.header");
		Iterator<Entry<String, JsonNode>> items = tmp.fields();
		while(items.hasNext()) {
			Entry<String, JsonNode> item = items.next();
			if( item.getValue().isArray() ) {
				ArrayNode an = (ArrayNode)item.getValue();
				for(int x=0; x<an.size(); x++) {
					hdr.add(item.getKey(), an.get(x).asText());
				}
			} else {
				hdr.add(item.getKey(), item.getValue().asText());
			}
		}
		
		//     2-3 URL 생성
		//         2-3-1 TODO: baseURL 생성 ( connector + 기본 url )
		//         2-3-2 Path variable 등록
		tmp = JsonPath.read(currNode, "$.input.path");
		items = tmp.fields();
		while(items.hasNext()) {
			Entry<String, JsonNode> item = items.next();
			uri.replaceAll("{" + item.getKey() + "}", item.getValue().asText());
		}
		//         2-3-3 queryString 등록
		tmp = JsonPath.read(currNode, "$.input.param");
		items = tmp.fields();
		boolean isFirst = true;
		while(items.hasNext()) {
			Entry<String, JsonNode> item = items.next();
			if( isFirst ) {
				uri += "?";
				isFirst = false;
			} else {
				uri += "&";
			}
			uri += (item.getKey() + "=" + item.getValue().asText());
		}
		HttpEntity<JsonNode> req = null;
		tmp = JsonPath.read(currNode, "$.input.body");
		if( tmp.size() > 0) {
			req = new HttpEntity<JsonNode>(tmp, hdr);
		} else {
			req = new HttpEntity<JsonNode>(null, hdr);
		}
		
		//     2-4 REST call
		RestTemplate rt = new RestTemplate();
		ResponseEntity<JsonNode> res = rt.exchange(uri, method, req, JsonNode.class);
		
		//     2-5 Response 처리
		//         2-5-1 response header 처리
		HttpHeaders resHdr = res.getHeaders();

		for(Entry<String, List<String>> e : resHdr.entrySet()) {
			if( e.getValue().size() > 1 ) {
				ArrayNode va = currNode.arrayNode();
				for( String str : e.getValue() ) {
					va.add(str);
				}
				((ObjectNode)JsonPath.read(currNode, "$.output.header")).set(e.getKey(), va);
				
			} else {
				((ObjectNode)JsonPath.read(currNode, "$.output.header")).put(e.getKey(), e.getValue().get(0));
			}
		}
		
		//         2-5-2 body 처리
		((ObjectNode)JsonPath.read(currNode, "$.output")).set("body", res.getBody());
		
		return res.getStatusCode();
	}
}
