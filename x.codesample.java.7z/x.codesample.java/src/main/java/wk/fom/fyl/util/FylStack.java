package wk.fom.fyl.util;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

public class FylStack {
	private int idx;
	private List<JsonNode> data;
	
	public FylStack() {
		idx = -1;
		data = new ArrayList<JsonNode>();
	}
	
	public void clear() {
		idx = -1;
		data = new ArrayList<JsonNode>();
	}
	
	public synchronized void push(JsonNode node) {
		idx++;
		data.add(node);
	}
	
	public synchronized JsonNode pop() {
		JsonNode ret = data.get(idx);
		data.remove(idx);
		idx--;
		return ret;
	}
	
	public JsonNode top() {
		return data.get(idx);
	}
}
