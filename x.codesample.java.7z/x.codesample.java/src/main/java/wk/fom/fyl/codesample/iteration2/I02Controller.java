package wk.fom.fyl.codesample.iteration2;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.JsonPath;

import wk.fom.fyl.codesample.util.FylStack;

@RestController
public class I02Controller {
	private ObjectMapper mapper;
	private ObjectNode root;
	private FylStack parent;
	
	public I02Controller() {
		mapper = new ObjectMapper();
		parent = new FylStack();
	}
	
	@GetMapping("/mapi/v2/myproject/{projectId}/catalogs")
	public @ResponseBody ResponseEntity<JsonNode> getUserdCatalog(
			@RequestHeader HttpHeaders header
			, @PathVariable("projectId") String projectId
			){
		root = mapper.createObjectNode();
		parent.clear();
		parent.push(root);
		
		// 1. flow input 처리 
		//     1-1. header 처리
		ObjectNode inputTask = I02Util.makeNormalTaskData(parent.top(), "flowMain");
		I02Util.setHeaderJson(inputTask, "$.input.header", header);
		//     1-2. path 처리
		((ObjectNode)JsonPath.read(root, "$.flowMain.input.path")).put("projectId", projectId);
		//     1-3. param 처리
		//     1-4. body 처리
		
		// 2. Task 1 수행
		
		run_Task01_getCatalog();
		
		// 3. Task 2 수행 ( foreach )
		run_foreach();

		return new ResponseEntity<JsonNode>(JsonPath.read(root, "$.flowMain.output.body"), header, HttpStatus.OK);		
	}

	private HttpStatus run_Task01_getCatalog() {
		ObjectNode currTask = I02Util.makeNormalTaskData(parent.top(), "getCatalog");
		//     2-1. input data 구성
		//         2-1-1 header 구성
		((ObjectNode)JsonPath.read(currTask, "$.input")).set("header", JsonPath.read(root, "$.flowMain.input.header"));
		//         2-1-2 path, param, body 구성
		((ObjectNode)JsonPath.read(currTask, "$.input.param")).set("useProjectId", JsonPath.read(root, "$.flowMain.input.path.projectId"));
		
		String uri = "http://localhost:80/api/v1/catalog/"; 
		return I02Util.callRestApi(uri, currTask, HttpMethod.GET);
	}
	
	private HttpStatus run_Task02_getCatalogRegUserName() {
		ObjectNode currTask = I02Util.makeNormalTaskData(parent.top(), "getCatalogRegUserName");
		((ObjectNode)JsonPath.read(currTask, "$.input")).set("header", JsonPath.read(root, "$.flowMain.input.header"));
		((ObjectNode)JsonPath.read(currTask, "$.input.path")).set("userId", JsonPath.read(parent.top(), "$.foreach_data.regUserId"));
		String uri = "http://localhost:80/api/v1/users/{userId}/";
		return I02Util.callRestApi(uri, currTask, HttpMethod.GET);
	}


	// 3. Task 2 수행 ( foreach )
	private void run_foreach(){
		ArrayNode thisArr = I02Util.makeLoopTask(parent.top(), "foreach");
		parent.push(thisArr);
		ArrayNode arr = JsonPath.read(root, "$.getCatalog.output.body");
		for(JsonNode loopData : arr) {
			//[S] 루프 구조
			ObjectNode loopObject = I02Util.makeLoopObject(parent.top(), "foreach", loopData);
			parent.push(loopObject);
			//[S] 루프 구조
			
			// task 수행
			run_Task02_getCatalogRegUserName();
			
				
			//[E] 루프 구조
			ObjectNode output = loopObject.objectNode();
			output.set("catalogId", JsonPath.read(loopObject, "$.foreach_data.catalogId"));
			output.set("catalogType", JsonPath.read(loopObject, "$.foreach_data.catalogType"));
			output.set("description", JsonPath.read(loopObject, "$.foreach_data.description"));
			output.set("useCount", JsonPath.read(loopObject, "$.foreach_data.useCount"));
			output.set("regUserId", JsonPath.read(loopObject, "$.foreach_data.regUserId"));
			output.set("regUserName", JsonPath.read(loopObject, "$.getCatalogRegUserName.output.body.userName"));
			
			ArrayNode rootOutput = I02Util.checkArray(root, "$.flowMain.output.body");
			rootOutput.add(output);
			parent.pop();
		}
		parent.pop();
	}
}