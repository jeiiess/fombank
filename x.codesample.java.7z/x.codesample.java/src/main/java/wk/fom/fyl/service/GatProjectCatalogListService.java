package wk.fom.fyl.service;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.jayway.jsonpath.JsonPath;

import wk.fom.fyl.util.FylUtil;

@Service
public class GatProjectCatalogListService {
	private ObjectMapper mapper;
	private ObjectNode   data;
	public String run(HttpHeaders headers, String projectId) {
		
		// 0. initialize private variables
		mapper = new ObjectMapper();
		data = mapper.createObjectNode();
		
		// 1. input value setting
		
		//---- 1.1 create flow main data object 
		FylUtil.makeWkNode(mapper, data, "flowMain");
		//---- 1-2 set flow input variable
		FylUtil.setString(data, "$.flowMain.input.param", "projectId", projectId);
		
		// 2. run Flow step
		runTask001_getCatalog();
		
		return FylUtil.getJson(data, "$.getCatalog.output.body").toString();
	}
	
	private void runTask001_getCatalog() {
		// REST-call 의 경우
		// 1. initialize
		RestTemplate rest = new RestTemplate();
		FylUtil.makeWkNode(mapper, data, "getCatalog");
		
		// 2. make input data
		FylUtil.setString(data, "$.getCatalog.input.param", "projectId"
				, FylUtil.getStr(data, "$.flowMain.input.param.projectId"));
		
		
		// 3. makeURL
		String url = String.format("http://localhost:80/api/v1/catalog/?useProjectId=%s",
				FylUtil.getStr(data, "$.getCatalog.input.param.projectId"));
		
		// 4. makeData / header
		
		// 5. call REST-api
		JsonNode result = rest.getForObject(url, JsonNode.class);
		
		// 6. set result to data
		FylUtil.setJson(data, "$.getCatalog.output", "body", result);
	}
}
