package wk.fom.fyl.codesample.iteration1;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class I01Service {
	private ObjectMapper mapper;
	private ObjectNode   data;
	private Map<String, JsonNode> tmpData;
	
	public JsonNode run(HttpHeaders headers, String projectId) {
		
		// 0. initialize private variables
		mapper = new ObjectMapper();
		data = mapper.createObjectNode();
		tmpData = new HashMap<String, JsonNode>();
		
		// 1. input value setting
		
		//---- 1.1 create flow main data object 
		I01Util.makeWkNode(mapper, data, "flowMain");
		//---- 1-2 set flow input variable
		I01Util.setString(data, "$.flowMain.input.param", "projectId", projectId);
		
		// 2. run Flow step
		runTask001_getCatalog();
		
		runTask002_foreach();
		
		return I01Util.getJson(data, "$.flowMain.output.body");
	}
	
	private void runTask001_getCatalog() {
		// REST-call 의 경우
		// 1. initialize
		RestTemplate rest = new RestTemplate();
		I01Util.makeWkNode(mapper, data, "getCatalog");
		
		// 2. make input data
		I01Util.setString(data, "$.getCatalog.input.param", "projectId"
				, I01Util.getStr(data, "$.flowMain.input.param.projectId"));
		
		
		// 3. makeURL
		String url = String.format("http://localhost:80/api/v1/catalog/?useProjectId=%s",
				I01Util.getStr(data, "$.getCatalog.input.param.projectId"));
		
		// 4. makeData / header
		
		// 5. call REST-api
		JsonNode result = rest.getForObject(url, JsonNode.class);
		
		// 6. set result to data
		I01Util.setJson(data, "$.getCatalog.output", "body", result);
	}
	
	private void runTask002_foreach() {
		JsonNode arr = I01Util.getJson(data, "$.getCatalog.output.body");
		
		for(JsonNode jn : arr) {
			tmpData.put("foreach", jn);
			runTask003_getCatalogRegUserName();

			runTask004_makeResult();
		}
	}
	
	private void runTask003_getCatalogRegUserName() {
		// REST-call 의 경우
		// 1. initialize
		RestTemplate rest = new RestTemplate();
		I01Util.makeWkNode(mapper, data, "getCatalogRegUserName");
		
		JsonNode item = tmpData.get("foreach");
		
		// 2. make input data
		I01Util.setString(data, "$.getCatalogRegUserName.input.path", "userId"
				, I01Util.getStr((ObjectNode)item, "$.regUserId"));
		
		// 3. makeURL
		String url = String.format("http://localhost:80/api/v1/users/%s",
				I01Util.getStr(data, "$.getCatalogRegUserName.input.path.userId"));
		
		// 4. makeData / header
		
		// 5. call REST-api
		JsonNode result = rest.getForObject(url, JsonNode.class);
		
		// 6. set result to data
		I01Util.setJson(data, "$.getCatalogRegUserName.output", "body", result);
	}
	
	private void runTask004_makeResult() {
		JsonNode jn = tmpData.get("foreach");
		
		ObjectNode node = mapper.createObjectNode();
		node.put("catalogId", I01Util.getStr(jn, "$.catalogId"));
		node.put("catalogType", I01Util.getStr(jn, "$.catalogType"));
		node.put("description", I01Util.getStr(jn, "$.description"));
		node.put("useCount", jn.get("useCount").asInt());
		node.put("regUserId", I01Util.getStr(jn, "$.regUserId"));
		node.put("regUserName"
				, I01Util.getStr(data
						, "$.getCatalogRegUserName.output.body.userName"));
		
		I01Util.addJson(data, "$.flowMain.output.body", node);
		
	}
}
