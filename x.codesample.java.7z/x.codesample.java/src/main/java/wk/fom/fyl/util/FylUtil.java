package wk.fom.fyl.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.jayway.jsonpath.JsonPath;

public class FylUtil {
	private static final int INPUT_STRUCT = 0;
	private static final int OUTPUT_STRUCT = 1;
	
//	public static void initializeService(ObjectMapper mapper, ObjectNode objNode) {
//		mapper = new ObjectMapper();
//		objNode = mapper.createObjectNode();
//		makeWkNode(mapper, objNode, "flowMain");
//	}
	
	public static void makeWkNode(ObjectMapper mapper, ObjectNode objNode, String nodeName) {
		ObjectNode node = mapper.createObjectNode();
		node.set("input", FylUtil.makeNode(INPUT_STRUCT, mapper));
		node.set("output", FylUtil.makeNode(OUTPUT_STRUCT, mapper));
		objNode.set(nodeName, node);
	}
	
	private static ObjectNode makeNode(int structType, ObjectMapper mapper) {
		ObjectNode node = mapper.createObjectNode();
		if( structType == FylUtil.INPUT_STRUCT) {
			node.set("header", mapper.createObjectNode());
			node.set("path", mapper.createObjectNode());
			node.set("param", mapper.createObjectNode());
			node.set("body", mapper.createObjectNode());
		} else {
			node.set("header", mapper.createObjectNode());
			node.set("body", mapper.createObjectNode());
		}
		return node;
	}
	
	public static void setString(ObjectNode objNode, String path, String nodeName, String value) {
		ObjectNode tgt = JsonPath.read(objNode, path);
		tgt.put(nodeName, value);
	}
	
	public static void setJson(ObjectNode objNode, String path, String nodeName, JsonNode value) {
		ObjectNode tgt = JsonPath.read(objNode, path);
		tgt.set(nodeName, value);
	}
	
	public static String getStr(ObjectNode node, String path) {
		return ((TextNode)JsonPath.read(node, path)).asText();
	}

	public static JsonNode getJson(ObjectNode node, String path) {
		return JsonPath.read(node, path);
	}
}
