package wk.fom.fyl.codesample.iteration1;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;

public class I01Util {
	private static final int INPUT_STRUCT = 0;
	private static final int OUTPUT_STRUCT = 1;
	
//	public static void initializeService(ObjectMapper mapper, ObjectNode objNode) {
//		mapper = new ObjectMapper();
//		objNode = mapper.createObjectNode();
//		makeWkNode(mapper, objNode, "flowMain");
//	}
	
	public static void makeWkNode(ObjectMapper mapper, ObjectNode objNode, String nodeName) {
		ObjectNode node = mapper.createObjectNode();
		node.set("input", I01Util.makeNode(INPUT_STRUCT, mapper));
		node.set("output", I01Util.makeNode(OUTPUT_STRUCT, mapper));
		objNode.set(nodeName, node);
	}
	
	private static ObjectNode makeNode(int structType, ObjectMapper mapper) {
		ObjectNode node = mapper.createObjectNode();
		if( structType == I01Util.INPUT_STRUCT) {
			node.set("header", mapper.createObjectNode());
			node.set("path", mapper.createObjectNode());
			node.set("param", mapper.createObjectNode());
			node.set("body", mapper.createObjectNode());
		} else {
			node.set("header", mapper.createObjectNode());
			node.set("body", mapper.createObjectNode());
		}
		return node;
	}
	
	public static void setString(ObjectNode objNode, String path, String nodeName, String value) {
		ObjectNode tgt = JsonPath.read(objNode, path);
		tgt.put(nodeName, value);
	}
	
	public static void setJson(ObjectNode objNode, String path, String nodeName, JsonNode value) {
		ObjectNode tgt = JsonPath.read(objNode, path);
		tgt.set(nodeName, value);
	}
	
	public static void addString(ObjectNode objNode, String path, String value) {
		ArrayNode tgt = null;
		try {
			JsonNode tmp = JsonPath.read(objNode, path);
			if( tmp.isArray() )
				tgt = (ArrayNode)tmp;
			else
				tgt = I01Util.makeArrayChild(objNode, path);
			tgt = JsonPath.read(objNode, path);
		} catch ( PathNotFoundException pnfe ) {
			tgt = I01Util.makeArrayChild(objNode, path);
		}
		
		tgt.add(value);
	}
	
	public static void addJson(ObjectNode objNode, String path, JsonNode value) {
		ArrayNode tgt = null;
		try {
			JsonNode tmp = JsonPath.read(objNode, path);
			if( tmp.isArray() )
				tgt = (ArrayNode)tmp;
			else
				tgt = I01Util.makeArrayChild(objNode, path);
		} catch ( PathNotFoundException pnfe ) {
			tgt = I01Util.makeArrayChild(objNode, path);
		} 
		tgt.add(value);
	}
	
	public static String getStr(ObjectNode node, String path) {
		return ((TextNode)JsonPath.read(node, path)).asText();
	}

	public static JsonNode getJson(ObjectNode node, String path) {
		return JsonPath.read(node, path);
	}

	public static String getStr(JsonNode node, String path) {
		return ((TextNode)JsonPath.read(node, path)).asText();
	}

	public static JsonNode getJson(JsonNode node, String path) {
		return JsonPath.read(node, path);
	}
	
	public static Map<String, String> getParentInfo(String path) {
		Map<String, String> ret = new HashMap<String, String>();
		int idx = path.lastIndexOf('.');
		ret.put("parentPath", path.substring(0, idx));
		ret.put("fieldName", path.substring(idx+1));
		return ret;
	}
	
	public static ArrayNode makeArrayChild(ObjectNode objNode, String path) {
		Map<String, String> pMap = getParentInfo(path);
		ObjectNode pNode = JsonPath.read(objNode, pMap.get("parentPath"));
		pNode.putArray(pMap.get("fieldName"));
		return (ArrayNode)pNode.get(pMap.get("fieldName"));
	}
}
