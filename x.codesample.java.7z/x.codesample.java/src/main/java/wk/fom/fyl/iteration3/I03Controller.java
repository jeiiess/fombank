package wk.fom.fyl.iteration3;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.JsonPath;

import wk.fom.fyl.iteration3.I03Util;
import wk.fom.fyl.util.FylStack;

@RestController
public class I03Controller {
	private ObjectMapper mapper;
	private ObjectNode root;
	private FylStack parent;
	private HttpStatus retStatus;
	private boolean isEnd;
	
	public I03Controller() {
		mapper = new ObjectMapper();
		parent = new FylStack();
	}
	

	@GetMapping("/mapi/v3/myproject/{projectId}/catalogs")
	public @ResponseBody ResponseEntity<JsonNode> getUserdCatalog(
			@RequestHeader HttpHeaders header
			, @PathVariable("projectId") String projectId
			){
		retStatus = HttpStatus.OK;
		isEnd = false;
		root = mapper.createObjectNode();
		parent.clear();
		parent.push(root);
		
		// 1. flow input 처리 
		//     1-1. header 처리
		ObjectNode inputTask = I03Util.makeNormalTaskData(parent.top(), "start");
		I03Util.setHeaderJson(inputTask, "$.input.header", header);
		//     1-2. path 처리
		((ObjectNode)JsonPath.read(root, "$.start.input.path")).put("projectId", projectId);
		//     1-3. param 처리
		//     1-4. body 처리
		
		// 2. Task 1 수행
		if( !isEnd ) {
			switch(run_Task01_getCatalog().value()) {
			case 200:
				retStatus = HttpStatus.valueOf(200);
				break;
			case 404:
				retStatus = HttpStatus.valueOf(404);
				
			}	
		}
		
		// 3. Task 2 수행 ( foreach )
		if( !isEnd ) {
			run_loop01_foreach();
		}
		
		
		// 4. workflow 종료 처리 ( 출력편집 )
		if( !isEnd ) {
			end_workflow();
		}

		return new ResponseEntity<JsonNode>(JsonPath.read(root, "$.start.output.body"), header, retStatus);		
//		return new ResponseEntity<JsonNode>(JsonPath.read(root, "$"), header, HttpStatus.OK);
	}

	private HttpStatus run_Task01_getCatalog() {
		ObjectNode currTask = I03Util.makeNormalTaskData(parent.top(), "getCatalog");
		//     2-1. input data 구성
		//         2-1-1 header 구성
		((ObjectNode)JsonPath.read(currTask, "$.input")).set("header", JsonPath.read(root, "$.start.input.header"));
		//         2-1-2 path, param, body 구성
		((ObjectNode)JsonPath.read(currTask, "$.input.param")).set("useProjectId", JsonPath.read(root, "$.start.input.path.projectId"));
		
		String uri = "http://localhost:80/api/v1/catalog/"; 
		return I03Util.callRestApi(uri, currTask, HttpMethod.GET);
	}
	
	private HttpStatus run_Task02_getCatalogRegUserName() {
		ObjectNode currTask = I03Util.makeNormalTaskData(parent.top(), "getCatalogRegUserName");
		((ObjectNode)JsonPath.read(currTask, "$.input")).set("header", JsonPath.read(root, "$.start.input.header"));
		((ObjectNode)JsonPath.read(currTask, "$.input.path")).set("userId", JsonPath.read(parent.top(), "$.foreach.input.regUserId"));
		String uri = "http://localhost:80/api/v1/users/{userId}/";
		return I03Util.callRestApi(uri, currTask, HttpMethod.GET);
	}
	
	private HttpStatus run_Task03_getProjectName() {
		ObjectNode currTask = I03Util.makeNormalTaskData(parent.top(), "getProjectName");
		((ObjectNode)JsonPath.read(currTask, "$.input")).set("header", JsonPath.read(root, "$.start.input.header"));
		((ObjectNode)JsonPath.read(currTask, "$.input.path")).set("projectId", JsonPath.read(parent.top(), "$.pjtLoop.input"));
		String uri = "http://localhost:80/api/v1/projects/{projectId}/";
		return I03Util.callRestApi(uri, currTask, HttpMethod.GET);
	}


	// 3. Task 2 수행 ( foreach )
	private void run_loop01_foreach(){
		ArrayNode arr = JsonPath.read(parent.top(), "$.getCatalog.output.body");
		
		ObjectNode currTask = I03Util.makeLoopTask(parent.top(), "foreach");
		parent.push(currTask);		
		for(JsonNode loopData : arr) {
			//[S] 루프 구조
			ObjectNode loopObject = I03Util.makeLoopObject(parent.top(), "foreach", loopData);
			parent.push(loopObject);
			//[S] 루프 구조
			
			// task 수행
			run_Task02_getCatalogRegUserName();
			
			run_loop02_pjtLoop();
				
			//[E] 루프 구조
			parent.pop();

			ObjectNode output = loopObject.objectNode();
			output.set("catalogId", JsonPath.read(loopObject, "$.foreach.input.catalogId"));
			output.set("catalogType", JsonPath.read(loopObject, "$.foreach.input.catalogType"));
			output.set("description", JsonPath.read(loopObject, "$.foreach.input.description"));
			output.set("useCount", JsonPath.read(loopObject, "$.foreach.input.useCount"));
			output.set("regUserId", JsonPath.read(loopObject, "$.foreach.input.regUserId"));
			output.set("regUserName", JsonPath.read(loopObject, "$.getCatalogRegUserName.output.body.userName"));
			output.set("pjtList", JsonPath.read(loopObject, "$.pjtLoop.output"));
			
			((ArrayNode)currTask.get("output")).add(output);
		}
		parent.pop();
	}

	private void run_loop02_pjtLoop() {
		ArrayNode arr = JsonPath.read(parent.top(), "$.foreach.useProjectList");
		
		ObjectNode currTask = I03Util.makeLoopTask(parent.top(), "pjtLoop");
		parent.push(currTask);

		for(JsonNode loopData : arr) {
			//[S] 루프 구조
			ObjectNode loopObject = I03Util.makeLoopObject(parent.top(), "pjtLoop", loopData);
			parent.push(loopObject);
			//[S] 루프 구조
			
			// task 수행
			run_Task03_getProjectName();
							
			//[E] 루프 구조
			parent.pop();

			ObjectNode output = loopObject.objectNode();
			output.set("projectId", JsonPath.read(loopObject, "$.pjtLoop.input"));
			output.set("projectName", JsonPath.read(loopObject, "$.getProjectName.output.body.projectName"));
			output.set("ownerId", JsonPath.read(loopObject, "$.getProjectName.output.body.ownerId"));
			
			((ArrayNode)currTask.get("output")).add(output);
		}
		parent.pop();
	}
	
	private void end_workflow() {
		// End를 어떻게 구성할지 고민이 필요함
		ArrayNode arr = JsonPath.read(root, "$.foreach.output");
		ArrayNode mainOutput = I03Util.checkArray(root, "$.start.output.body");
		for( JsonNode itm : arr ) {
			ObjectNode output = root.objectNode();
			output.set("catalogId", JsonPath.read(itm, "$.catalogId"));
			output.set("catalogType", JsonPath.read(itm, "$.catalogType"));
			output.set("useCount", JsonPath.read(itm, "$.useCount"));
			output.set("regUser", JsonPath.read(itm, "$.regUserName"));
			output.set("usedProjectList", JsonPath.read(itm, "$.pjtList"));
			
			mainOutput.add(output);
		}
	}
}
