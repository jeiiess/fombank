package wk.fom.fyl.iteration2;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.JsonPath;

@RestController
public class I02Controller {
	private ObjectMapper mapper;
	private ObjectNode data;
	private Map<String, JsonNode> tmpData;
	
	public I02Controller() {
		mapper = new ObjectMapper();
	}
	
	@GetMapping("/mapi/v2/myproject/{projectId}/catalogs")
	public @ResponseBody ResponseEntity<JsonNode> getUserdCatalog(
			@RequestHeader HttpHeaders header
			, @PathVariable("projectId") String projectId
			){
		data = mapper.createObjectNode();
		ObjectNode currTask = I02Util.makeNormalTaskData(data, "flowMain");
		tmpData = new HashMap<String, JsonNode>();
				
		// 1. flow input 처리 
		//     1-1. header 처리
		I02Util.setHeaderJson(currTask, "$.input.header", header);
		//     1-2. path 처리
		((ObjectNode)JsonPath.read(data, "$.flowMain.input.path")).put("projectId", projectId);
		//     1-3. param 처리
		//     1-4. body 처리
		
		// 2. Task 1 수행
		
		run_Task01_getCatalog();
		
		// 3. Task 2 수행 ( foreach )
		{
			currTask = I02Util.makeLoopTaskData(data, "foreach");
			ArrayNode arr = JsonPath.read(data, "$.getCatalog.output.body");
			for(JsonNode loopData : arr) {
				tmpData.put("foreach", loopData);
			}
		}

		return new ResponseEntity<JsonNode>(data, header, HttpStatus.OK);		
	}

	private void run_Task01_getCatalog() {
		ObjectNode currTask = I02Util.makeNormalTaskData(data, "getCatalog");
		//     2-1. input data 구성
		//         2-1-1 header 구성
		((ObjectNode)JsonPath.read(currTask, "$.input")).set("header", JsonPath.read(data, "$.flowMain.input.header"));
		//         2-1-2 path, param, body 구성
		((ObjectNode)JsonPath.read(currTask, "$.input.param")).set("useProjectId", JsonPath.read(data, "$.flowMain.input.path.projectId"));
		
		String uri = "http://localhost:80/api/v1/catalog/"; 
		HttpStatus httpStatus = I02Util.callRestApi(uri, currTask, HttpMethod.GET);
	}
}
