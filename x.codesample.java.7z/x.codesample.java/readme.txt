== fyl 구성을 위한 source sample
1. REST-API ochestration
  - z.source.catalog 에서 
    0. GET /mapi/v2/myproject/{projectId}/catalogs
    1. 특정 프로젝트에서 사용하는 카탈로그 모두 조회
        . /api/v1/catalog?useProject={projectId}
    2. 개별 카탈로그의 등록자명을 조회
        . /api/v1/users/{userId}
    3. 카탈로그ID, description, 등록자명을 return
2. JDBC template and pool 예제
