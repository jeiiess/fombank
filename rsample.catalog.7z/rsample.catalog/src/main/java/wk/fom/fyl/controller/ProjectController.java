package wk.fom.fyl.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import wk.fom.fyl.repository.IdGenerator;
import wk.fom.fyl.repository.ProjectDB;
import wk.fom.fyl.vo.ProjectVO;

@RestController
@RequestMapping("/api/v1/projects")
public class ProjectController {
	@Autowired
	private ProjectDB projectDB;
	
	@Autowired
	private IdGenerator idGenerator;
	
	@PostMapping("/")
	public String addProject(@RequestBody ProjectVO vo) {
		String projectId = idGenerator.getProjectId();
		vo.setProjectId(projectId);
		projectDB.put(vo);
		return projectId;
	}
	
	@GetMapping("/")
	public List<ProjectVO> getProjectList(
			@RequestParam("ids") Optional<List<String>> ids,
			@RequestParam("projectName") Optional<String> projectName,
			@RequestParam("ownerUserId") Optional<String> ownerUserId
			){
		if(ids.isPresent()) {
			List<ProjectVO> lst = new ArrayList<ProjectVO>();
			for(String id : ids.get()) {
				lst.add(projectDB.get(id));
			}
			return lst;
		} else if( projectName.isPresent() ) {
			return projectDB.getByName(projectName.get());
		} else if( ownerUserId.isPresent() ) {
			return projectDB.getByOwner(ownerUserId.get());
		} else {
			return null;
		}
	}
	
	@GetMapping("/{projectId}")
	public ProjectVO getProject(@PathVariable("projectId") String projectId) {
		return projectDB.get(projectId);
	}
}
