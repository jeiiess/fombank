package wk.fom.fyl.builder.srcgen.struct.instance;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import wk.fom.fyl.builder.srcgen.struct.workflow.Workflow;

public class Instance {
	public static final String INSTANCE_ID = "instanceId";
	public static final String SYSTEMS = "systems";
	public static final String CONNECTORS = "connectors";
	public static final String POOLS = "pools";
	public static final String CONFIG = "config";
	public static final String WORKFLOWS = "workflows";
	
	private String baseDir;
	private String fileName;
	private String fileType;
	
	private String id;
	private List<SystemType> systemTypes;
	private List<Connector> connectors;
	private List<Pool> pools;
	private Config config;
	private List<String> wfId;
	private List<Workflow> workflows;
	
	public static Instance getInstance(String baseDir, String fileName, String fileType) 
			throws Exception {
		Instance ret = new Instance(baseDir, fileName, fileType);
		ret.load();
		return ret;
	}
	
	private Instance(String baseDir, String fileName, String fileType) {
		this.baseDir = baseDir;
		this.fileName = fileName;
		this.fileType = fileType.toUpperCase(Locale.getDefault());
		id = "";
		systemTypes = new ArrayList<SystemType>();
		connectors = new ArrayList<Connector>();
		pools = new ArrayList<Pool>();
		config = null;
		wfId = new ArrayList<String>();
		workflows = new ArrayList<Workflow>();
	}
	
	public void load() throws Exception {
		ObjectMapper mapper = null;
		if( this.fileType.equals("YAML") ) {
			mapper = new ObjectMapper(new YAMLFactory());
		} else {
			mapper = new ObjectMapper(new JsonFactory());
		}
		ObjectNode node = (ObjectNode) mapper.readTree(new File(this.baseDir + "/" + this.fileName) );
		
		parse(node);
	}
	
	public void parse(ObjectNode node) throws Exception {
		Iterator<String> keys = node.fieldNames();
		while(keys.hasNext()) {
			String k = keys.next();
			
			if ( k.equals(Instance.INSTANCE_ID) ) {
				this.id = node.get(k).asText();
				
			} else if ( k.equals(Instance.SYSTEMS) ) {
				ArrayNode ar = (ArrayNode) node.get(k);
				for( JsonNode jn : ar ) {
					systemTypes.add( SystemType.getInstance((ObjectNode)jn) );
				}
				
			} else if ( k.equals(Instance.CONNECTORS) ) {
				ArrayNode ar = (ArrayNode) node.get(k);
				for( JsonNode jn : ar ) {
					connectors.add( Connector.getInstance((ObjectNode)jn) );
				}
				
			} else if ( k.equals(Instance.POOLS) ) {
				ArrayNode ar = (ArrayNode) node.get(k);
				for( JsonNode jn : ar ) {
					pools.add( Pool.getInstance((ObjectNode)jn) );
				}
				
			} else if ( k.equals(Instance.CONFIG) ) {
				config = Config.getInstance((ObjectNode) node.get(k));
				
			} else if ( k.equals(Instance.WORKFLOWS) ) {
				ArrayNode ar = (ArrayNode) node.get(k);
				for( JsonNode wk : ar) {
					wfId.add( wk.asText() );
					Workflow workflow = new Workflow();
					workflow.load(wk.asText(), this.baseDir);
					this.workflows.add(workflow);
				}
				
			} else {
				
			}
		}
	}

	@Override
	public String toString() {
		return "Instance [baseDir=" + baseDir + ", fileName=" + fileName + ", fileType=" + fileType + ", id=" + id
				+ ", systemTypes=" + systemTypes + ", connectors=" + connectors + ", pools=" + pools + ", config="
				+ config + ", wfId=" + wfId + ", workflows=" + workflows + "]";
	}
}
