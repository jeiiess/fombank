package wk.fom.fyl.builder.srcgen.builder;

import java.util.Locale;

import wk.fom.fyl.builder.srcgen.builder.v1.java.springboot.JVSBFlowBuilder;

public class FlowBuilderFactory {
	public static IFlowBuilder getFlowBuilder() {
		String lang = System.getProperty("flowLang", "java").toLowerCase(Locale.getDefault());
		String fw = System.getProperty("flowFramework","springboot").toLowerCase(Locale.getDefault());
		
		if( lang.equals("java") ) {
			if( fw.equals("springboot") ) {
				return new JVSBFlowBuilder();
			} else {
				System.out.println("not yet!");
				return null;
			}
		} else if( lang.equals("go") ) {
			System.out.println("Not Yet!");
			return null;
		} else {
			System.out.println("XXX");
			return null;
		}
	}
}
