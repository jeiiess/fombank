package wk.fom.fyl.builder.srcgen.struct;

import wk.fom.fyl.builder.srcgen.struct.task.Task;

public enum TaskType {
	START("wk.fom.fyl.builder.srcgen.struct.task.StartTask"),
	END("wk.fom.fyl.builder.srcgen.struct.task.EndTask"),
	RESTAPI("wk.fom.fyl.builder.srcgen.struct.task.RestApiTask"),
	CONDITION("wk.fom.fyl.builder.srcgen.struct.task.ConditionTask"),
	SQL("wk.fom.fyl.builder.srcgen.struct.task.SqlTask")
	
	;
	
	private String cName;
	
	TaskType(String cName){ this.cName = cName; }
	
	public String getClassName() { return this.cName; }
	
	public Task getInstance() {
		try {
			return (Task)Class.forName(cName).newInstance();
		} catch ( Exception ex ) {
			ex.printStackTrace();
			return null;
		}
	}
}

