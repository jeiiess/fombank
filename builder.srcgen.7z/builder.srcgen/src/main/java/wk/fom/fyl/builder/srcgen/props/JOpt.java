package wk.fom.fyl.builder.srcgen.props;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class JOpt {
	public static final int STRING = 1;
	public static final int BOOL = 2;
	public static final int INT = 3;
	public static final int LONG = 4;
	public static final int DOUBLE = 5;
	public static final int OBJECTNODE = 6;
	
	public static Object get(ObjectNode node, String nodeName, int returnType) {
		JsonNode jo = node.get(nodeName);
		if( jo == null ) {
			return null;
		}
		Object ret = null;
		switch(returnType) {
		case JOpt.STRING:
			ret = jo.asText();
			break;
		case JOpt.BOOL:
			ret = jo.asBoolean();
			break;
		case JOpt.INT:
			ret = jo.asInt();
			break;
		case JOpt.LONG:
			ret = jo.asLong();
			break;
		case JOpt.DOUBLE:
			ret = jo.asDouble();
			break;
		case JOpt.OBJECTNODE:
			ret = (ObjectNode)jo;
			break;
		default:
			ret = null;
		}
		
		return ret;
	}
}
