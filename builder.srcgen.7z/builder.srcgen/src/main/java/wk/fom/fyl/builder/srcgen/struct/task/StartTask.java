package wk.fom.fyl.builder.srcgen.struct.task;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.RestMethod;
import wk.fom.fyl.builder.srcgen.struct.model.param.Parameter;
import wk.fom.fyl.builder.srcgen.struct.model.response.Response;

public class StartTask extends Task {
	public static final String SERVICE_URL = "service_url";
	public static final String METHOD = "method";
	public static final String PARAMETER = "parameter";
	public static final String RESPONSE = "response";
	
	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		this.service_url = node.get(StartTask.SERVICE_URL).asText();
		
		this.method = RestMethod.valueOf(node.get(StartTask.METHOD).asText());
		
		this.parameter = new Parameter();
		ObjectNode param = (ObjectNode)node.get(StartTask.PARAMETER);
		this.parameter.parse(param);
		
		this.response = new Response();
		ObjectNode res = (ObjectNode)node.get(StartTask.RESPONSE);
		this.response.parse(res);
	}

	protected String service_url;
	protected RestMethod method;
	protected Parameter parameter;
	protected Response response;

	public StartTask() {
		parameter = new Parameter();
	}

	public String getService_url() {
		return service_url;
	}

	public RestMethod getMethod() {
		return method;
	}

	public Parameter getParameter() {
		return parameter;
	}

	public Response getResponse() {
		return response;
	}

	@Override
	public String toString() {
		return "StartTask [service_url=" + service_url + ", method=" + method + ", parameter=" + parameter
				+ ", response=" + response + ", taskType=" + taskType + ", taskId=" + taskId + ", description="
				+ description + "]";
	}
}
