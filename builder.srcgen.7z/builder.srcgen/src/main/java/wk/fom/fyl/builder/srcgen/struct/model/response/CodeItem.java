package wk.fom.fyl.builder.srcgen.struct.model.response;

import java.util.Iterator;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.model.Body;

public class CodeItem {
	public static final String DESCRIPTION = "description";
	public static final String ISEND = "isEnd";
	public static final String MAPPER = "mapper";
	public static final String BODY = "body";

	private String code;
	private String description;
	private boolean isEnd;
	private Mapper mapper;
	private Body body;
	
	public CodeItem() {
		this.code = "";
		this.description = "";
		this.isEnd = false;
		this.mapper = null;
		this.body = null;
	}
	
	public void parse(String code, ObjectNode node) {
		this.code = code;
		Iterator<String> ids = node.fieldNames();
		while( ids.hasNext() ) {
			String id = ids.next();
			
			if( CodeItem.DESCRIPTION.equals(id) ) {
				this.description = node.get(id).asText();
			} else if ( CodeItem.ISEND.equals(id) ) {
				this.isEnd = node.get(id).asBoolean(false);
			} else if ( CodeItem.MAPPER.equals(id) ) {
				this.mapper = new Mapper();
				this.mapper.parse((ObjectNode)node.get(id));
			} else if ( CodeItem.BODY.equals(id) ) {
				this.body = new Body();
				this.body.parse((ObjectNode)node.get(id));
			}
		}
	}

	public String getCode() {
		return code;
	}
	
	public String getDescription() {
		return description;
	}

	public boolean isEnd() {
		return isEnd;
	}

	public Mapper getMapper() {
		return mapper;
	}

	public Body getBody() {
		return body;
	}

	@Override
	public String toString() {
		return "CodeItem [code=" + code + ", description=" + description + ", isEnd=" + isEnd + ", mapper=" + mapper
				+ ", body=" + body + "]";
	}
}
