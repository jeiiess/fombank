package wk.fom.fyl.builder.srcgen.struct;

public enum RestMethod {
	GET,
	PUT,
	POST,
	DELETE
}
