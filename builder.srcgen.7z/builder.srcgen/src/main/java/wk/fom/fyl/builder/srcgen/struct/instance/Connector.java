package wk.fom.fyl.builder.srcgen.struct.instance;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.ConnectorType;

public abstract class Connector {
	public static final String ID = "id";
	public static final String TYPE = "type";
	
	protected String id;
	protected ConnectorType connectorType;
	
	public Connector() { }
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ConnectorType getConnectorType() {
		return connectorType;
	}
	public void setConnectorType(ConnectorType connectorType) {
		this.connectorType = connectorType;
	}
	
	public static Connector getInstance(ObjectNode node) {
		ConnectorType ct = ConnectorType.valueOf( node.get(Connector.TYPE).asText() );
		Connector ret = ct.getInstance();
		ret.setId( node.get(Connector.ID).asText() );
		ret.setConnectorType(ct);
		ret.parse(node);
		return ret;
	}
	
	public abstract void parse(ObjectNode node);
}
