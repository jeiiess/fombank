package wk.fom.fyl.builder.srcgen.struct.instance;

import com.fasterxml.jackson.databind.node.ObjectNode;

public class DbInfo {
	public static final String CONNECTION_STRING = "connStr";
	public static final String USERID = "userId";
	public static final String PASSWORD = "password";
	
	private String connStr;
	private String userId;
	private String password;
	
	public DbInfo(ObjectNode node) {
		this.connStr = node.get(DbInfo.CONNECTION_STRING).asText();
		this.userId = node.get(DbInfo.USERID).asText();
		this.password = node.get(DbInfo.PASSWORD).asText();
	}

	public String getConnStr() {
		return connStr;
	}

	public String getUserId() {
		return userId;
	}

	public String getPassword() {
		return password;
	}

	@Override
	public String toString() {
		return "DbInfo [connStr=" + connStr + ", userId=" + userId + ", password=" + password + "]";
	}
}
