package wk.fom.fyl.builder.srcgen.struct.model.param;

public class ParamItem {
	public static final String TYPE = "type";
	public static final String DESCRIPTION = "description";
	public static final String OPTIONAL = "optional";
	
	private String id;
	private String type;
	private String description;
	private boolean isOptional;
	
	public ParamItem(String id, String description, String type, String isOptional) {
		this.id = id;
		this.description = description;
		this.type = type;
		if( isOptional == null ) {
			this.isOptional = false;
		} else {
			String tmpIsOptional = isOptional.toLowerCase();
			
			if( ("y").equals(tmpIsOptional) || ("true").equals(tmpIsOptional)) {
				this.isOptional = true;
			} else {
				this.isOptional = false;
			}
		}
	}

	public String getId() {
		return id;
	}

	public String getType() {
		return type;
	}

	public String getDescription() {
		return description;
	}

	public boolean isOptional() {
		return isOptional;
	}

	@Override
	public String toString() {
		return "ParamItem [id=" + id + ", type=" + type + ", description=" + description + ", isOptional=" + isOptional
				+ "]";
	}
}
