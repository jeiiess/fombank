package wk.fom.fyl.builder.srcgen.struct.model.response;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.model.Body;

public class Response {
	public static final String BODY = "body";
	public static final String CODE = "code";
	
	private Body body;
	private List<CodeItem> code;
	
	public Response() { 
		code = new ArrayList<CodeItem>();
	}
	
	public void parse( ObjectNode node ) {
		Iterator<String> ids = node.fieldNames();
		while( ids.hasNext() ) {
			String id = ids.next();
			
			if( Response.BODY.equals(id) ) {
				this.body = new Body();
				this.body.parse((ObjectNode)node.get(id));
			} else if ( Response.CODE.equals(id) ) {
				ObjectNode cNode = (ObjectNode)node.get(id);
				Iterator<String> cds = cNode.fieldNames();
				while( cds.hasNext() ) {
					String cd = cds.next();
					CodeItem ci = new CodeItem();
					ci.parse(cd, (ObjectNode)cNode.get(cd));
					code.add(ci);
				}
			}
			
		}
	}

	public Body getBody() {
		return body;
	}

	public List<CodeItem> getCode() {
		return code;
	}

	@Override
	public String toString() {
		return "Response [body=" + body + ", code=" + code + "]";
	}
	
}
