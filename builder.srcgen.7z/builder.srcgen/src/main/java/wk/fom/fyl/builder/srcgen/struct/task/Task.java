package wk.fom.fyl.builder.srcgen.struct.task;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.props.JOpt;
import wk.fom.fyl.builder.srcgen.struct.TaskType;

public abstract class Task {
	public static final String TASK_TYPE = "taskType";
	public static final String TASK_ID = "taskId";
	public static final String DESCRIPTION = "description";
	public static final String OPTIONS = "options";
	
	public static Task getInstance(ObjectNode node) {
		TaskType tt = TaskType.valueOf(node.get(Task.TASK_TYPE).asText());
		Task ret = tt.getInstance();
		ret.setTaskType(tt);
		ret.setTaskId(node.get(Task.TASK_ID).asText());
		ret.setDescription((String)JOpt.get(node, Task.DESCRIPTION, JOpt.STRING));
		ret.setOptions((ObjectNode)JOpt.get(node, Task.OPTIONS, JOpt.OBJECTNODE));
		
		ret.parse(node);
		return ret;
	}
	
	public abstract void parse(ObjectNode node);
	
	protected TaskType taskType;
	protected String taskId;
	protected String description;
	protected Map<String, String> options;
	
	public TaskType getTaskType() {
		return taskType;
	}

	protected void setTaskType(TaskType taskType) {
		this.taskType = taskType;
	}

	public String getTaskId() {
		return taskId;
	}

	protected void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getDescription() {
		return description;
	}

	protected void setDescription(String description) {
		this.description = description;
	}
	
	public Map<String, String> getOptions(){
		return options;
	}
	
	protected void setOptions(ObjectNode node) {
		this.options = new HashMap<String, String>();
		if( node != null ) {
			Iterator<String> keys = node.fieldNames();
			while( keys.hasNext() ) {
				String key = keys.next();
				options.put(key, node.get(key).asText());
			}	
		}
	}

	@Override
	public String toString() {
		return "Task [taskType=" + taskType + ", taskId=" + taskId + ", description=" + description + ", options="
				+ options + "]";
	}
}
