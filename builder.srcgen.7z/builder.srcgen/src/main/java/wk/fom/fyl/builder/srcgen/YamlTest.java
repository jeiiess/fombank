package wk.fom.fyl.builder.srcgen;

import wk.fom.fyl.builder.srcgen.struct.instance.Instance;

public class YamlTest {
	public static void test001() {
		try {
			Instance ins = Instance.getInstance("D:\\A01.Workplace\\004.BMT_POC\\03.DEP\\45.Workflow\\10.개발진행\\TS.TestData"
					, "si.yaml"
					, "yaml");
			System.out.println(ins.toString());	
		} catch ( Exception ex ) {
			ex.printStackTrace();
		}
	}
}
