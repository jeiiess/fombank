package wk.fom.fyl.builder.srcgen.struct.model.util;

public class Tuple<K, V> {
	public K key;
	public V value;
	
	public Tuple(K key, V value){
		this.key = key;
		this.value = value;
	}
	
	@Override
	public String toString() {
		return "(" + key + "," + value + ")";
	}

	@Override
	public boolean equals(Object other) {
		if( other == this )
			return true;
		
		if( !(other instanceof Tuple) )
			return false;
		
		Tuple<K,V> o = (Tuple<K,V>) other;
		
		return o.key.equals(this.key) && o.value.equals(this.value);
	}
}
