package wk.fom.fyl.builder.srcgen.struct;

public enum LoopType {
	ARRAY
	;
}
