package wk.fom.fyl.builder.srcgen.struct;

import wk.fom.fyl.builder.srcgen.struct.instance.Pool;

public enum PoolType {
	DB_CONNECTION("wk.fom.fyl.builder.srcgen.struct.instance.poolimpl.DBConnectionPool")
	
	;
	
	private String cName;
	
	PoolType(String cName){
		this.cName = cName;
	}
	
	public String getClassName() {
		return this.cName;
	}
	
	public Pool getInstance() {
		try {
			return (Pool)Class.forName(cName).newInstance();
		} catch ( Exception ex ) {
			ex.printStackTrace();
			return null;
		}
	}
}
