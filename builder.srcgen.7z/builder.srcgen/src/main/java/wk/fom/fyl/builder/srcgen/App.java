package wk.fom.fyl.builder.srcgen;

public class App 
{
    public static void main( String[] args )
    {
    	YamlTest.test001();
    }
}
