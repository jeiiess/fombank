package wk.fom.fyl.builder.srcgen.struct.model.response;

import java.util.Iterator;

import com.fasterxml.jackson.databind.node.ObjectNode;

public class Mapper {
	public static final String CODE = "code";
	public static final String MESSAGE = "message";
	
	private int code;
	private String message;
	
	public Mapper() {
		
	}
	
	public void parse(ObjectNode node) {
		Iterator<String> ids = node.fieldNames();
		while( ids.hasNext() ) {
			String id = ids.next();
			
			if( Mapper.CODE.equals(id) ) {
				this.code = node.get(id).asInt();
			} else if( Mapper.MESSAGE.equals(id) ) {
				this.message = node.get(id).asText();
			}
		}
	}

	public int getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "Mapper [code=" + code + ", message=" + message + "]";
	}
}
