package wk.fom.fyl.builder.srcgen.struct.task;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.model.response.Response;

public class SqlTask extends Task {

	public SqlTask() {
		// TODO Auto-generated constructor stub
		param = new HashMap<String, String>();
	}

	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		
	}

	
	private Response response;
	private String sql;
	private Map<String, String> param;
	public Response getResponse() {
		return response;
	}

	public Map<String, String> getParam() {
		return param;
	}
	
	
}
