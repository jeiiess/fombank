package wk.fom.fyl.builder.srcgen.struct.instance;

import com.fasterxml.jackson.databind.node.ObjectNode;

public class SystemType {
	public static final String ID = "id";
	public static final String NAME = "name";
	private String id;
	private String name;

	public SystemType() { }
	
	public static SystemType getInstance(ObjectNode node) {
		SystemType st = new SystemType();
		st.parse(node);
		return st;
	}
	
	public void parse(ObjectNode node) {
		this.id = node.get(SystemType.ID).asText();
		this.name = node.get(SystemType.NAME).asText();
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "SystemType [id=" + id + ", name=" + name + "]";
	}
	
}
