package wk.fom.fyl.builder.srcgen.struct.instance;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.PoolType;

public abstract class Pool {
	public static final String ID = "id";
	public static final String TYPE = "type";
	public static final String MIN = "min";
	public static final String MAX = "max";
	public static final String LIBRARY = "library";
	
	public abstract void parse(ObjectNode node);
	
	public static Pool getInstance(ObjectNode node) {
		PoolType poolType = PoolType.valueOf(node.get(Pool.TYPE).asText());
		Pool pool = poolType.getInstance();
		pool.setId(node.get(Pool.ID).asText());
		pool.setType(poolType);
		pool.setMax(node.get(Pool.MAX).asInt());
		pool.setMin(node.get(Pool.MIN).asInt());
		
		ArrayNode tmp = (ArrayNode)node.get(Pool.LIBRARY);
		for( JsonNode cn : tmp) {
			pool.addLibrary(new Library((ObjectNode)cn));
		}
		
		pool.parse(node);
		return pool;
	}
	
	protected Pool() {
		libraries = new ArrayList<Library>();
	}
	
	protected String id;
	protected PoolType type;
	protected int min;
	protected int max;
	protected List<Library> libraries;

	public String getId() {
		return id;
	}
	protected void setId(String id) {
		this.id = id;
	}
	public PoolType getType() {
		return type;
	}
	protected void setType(PoolType type) {
		this.type = type;
	}
	public int getMin() {
		return min;
	}
	protected void setMin(int min) {
		this.min = min;
	}
	public int getMax() {
		return max;
	}
	protected void setMax(int max) {
		this.max = max;
	}

	public List<Library> getLibraries() {
		return libraries;
	}

	protected void addLibrary(Library lib) {
		this.libraries.add(lib);
	}
}
