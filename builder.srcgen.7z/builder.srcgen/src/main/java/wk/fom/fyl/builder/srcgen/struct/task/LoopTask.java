package wk.fom.fyl.builder.srcgen.struct.task;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.LoopItemType;
import wk.fom.fyl.builder.srcgen.struct.LoopType;
import wk.fom.fyl.builder.srcgen.struct.model.mediation.Mediation;
import wk.fom.fyl.builder.srcgen.struct.model.util.Tuple;

public class LoopTask extends Task {
	public static final String LOOP_TYPE = "loopType";
	public static final String LOOP_TARGET ="loopTarget";
	public static final String ITEM_TYPE ="itemType";
	public static final String TASKS = "tasks";
	public static final String LOOPOUTPUT = "loopOutput";

	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		Iterator<String> ids = node.fieldNames();
		while( ids.hasNext() ) {
			String id = ids.next();
			if( LoopTask.LOOP_TYPE.equals(id) ) {
				loopType = LoopType.valueOf( node.get(id).asText().toUpperCase(Locale.getDefault()) );
			} else if( LoopTask.LOOP_TARGET.equals(id) ) {
				loopTarget = node.get(id).asText();
			} else if( LoopTask.ITEM_TYPE.equals(id) ) {
				itemType = LoopItemType.valueOf( node.get(id).asText().toUpperCase(Locale.getDefault() ) );
			} else if( LoopTask.TASKS.equals(id) ) {
				tasks = new ArrayList<Task>();
				ArrayNode taskArray = (ArrayNode)node.get(id);
				for( int i=0; i<taskArray.size(); i++) {
					ObjectNode t = (ObjectNode)taskArray.get(i);
					tasks.add(Task.getInstance(t));
				}
			} else if( LoopTask.LOOPOUTPUT.equals(id) ) {
				this.loopOutput = new ArrayList<Tuple<String,String>>();
				ObjectNode subNode = (ObjectNode) node.get(id);
				Iterator<String> items = subNode.fieldNames();
				while( items.hasNext() ) {
					String item = items.next();
					loopOutput.add(new Tuple<String, String>(item, subNode.get(item).asText()));
				}
			}
		}
	}

	protected LoopType loopType;
	protected List<Task> tasks;
	protected String loopTarget;
	protected LoopItemType itemType;
	protected List<Tuple<String, String>> loopOutput;

	public LoopType getLoopType() {
		return loopType;
	}
	public List<Task> getTasks() {
		return tasks;
	}
	public String getLoopTarget() {
		return loopTarget;
	}
	public LoopItemType getItemType() {
		return itemType;
	}
	public List<Tuple<String, String>> getLoopOutput() {
		return loopOutput;
	}
	@Override
	public String toString() {
		return "LoopTask [loopType=" + loopType + ", tasks=" + tasks + ", loopTarget=" + loopTarget + ", itemType="
				+ itemType + ", loopOutput=" + loopOutput + "]";
	}
	
}
