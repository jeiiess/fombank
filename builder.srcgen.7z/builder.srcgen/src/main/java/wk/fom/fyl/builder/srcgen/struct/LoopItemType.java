package wk.fom.fyl.builder.srcgen.struct;

public enum LoopItemType {
	OBJECT
}
