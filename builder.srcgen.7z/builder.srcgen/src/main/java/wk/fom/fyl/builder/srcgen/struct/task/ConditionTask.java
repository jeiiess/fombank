package wk.fom.fyl.builder.srcgen.struct.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ConditionTask extends Task {
	public static final String CONDITION = "condition";
	public static final String OPERAND_TYPE = "operand_type";
	public static final String PATH = "path";

	public ConditionTask() {
		// TODO Auto-generated constructor stub
		path = new HashMap<String, List<Task>>();
	}

	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		this.condition = node.get(ConditionTask.CONDITION).asText();
		this.operandType = node.get(ConditionTask.OPERAND_TYPE).asText();
		
		ObjectNode subNode = (ObjectNode)node.get(ConditionTask.PATH);
		Iterator<String> ids = subNode.fieldNames();
		while( ids.hasNext() ) {
			String id = ids.next();
			List<Task> taskList = new ArrayList<Task>();
			
			ArrayNode tasks = (ArrayNode)subNode.get(id);
			for( int i=0; i<tasks.size(); i++) {
				ObjectNode t = (ObjectNode)tasks.get(i);
				taskList.add(Task.getInstance(t));
			}
			
			path.put(id, taskList);
		}
	}
	
	private String condition;
	private String operandType;
	private Map<String, List<Task>> path;

	public String getCondition() {
		return condition;
	}

	public String getOperandType() {
		return operandType;
	}

	public Map<String, List<Task>> getPath() {
		return path;
	}

	@Override
	public String toString() {
		return "ConditionTask [condition=" + condition + ", operandType=" + operandType + ", path=" + path
				+ ", taskType=" + taskType + ", taskId=" + taskId + ", description=" + description + "]";
	}
}
