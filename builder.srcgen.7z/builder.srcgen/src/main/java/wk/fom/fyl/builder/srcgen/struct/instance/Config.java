package wk.fom.fyl.builder.srcgen.struct.instance;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;

public class Config {
	public static final String ENV = "env";
	public static final String CMDLINE = "cmdline";
	public static Config getInstance(ObjectNode node) {
		Config ret = new Config();
		ret.parse(node);
		return ret;
	}
	
	private Map<String, Map<String, String>> env;
	private Map<String, Map<String, String>> cmdline;
	
	private Config() {
		env = new HashMap<String, Map<String,String>>();
		cmdline = new HashMap<String, Map<String,String>>();
	}

	public void parse(ObjectNode node) {
		Iterator<String> configTypes = node.fieldNames();
		while(configTypes.hasNext()) {
			String configType = configTypes.next();
			ObjectNode tmp1 = (ObjectNode)node.get(configType);
			
			Iterator<String> sysTypes = tmp1.fieldNames();
			while(sysTypes.hasNext()) {
				String sysType = sysTypes.next();
				ObjectNode tmp2 = (ObjectNode)tmp1.get(sysType);
				
				Map<String, String> itm = new HashMap<String, String>();
				
				Iterator<String> keys = tmp2.fieldNames();
				while(keys.hasNext()) {
					String key = keys.next();
					itm.put(key, tmp2.get(key).asText());
				}
				
				if( Config.ENV.equals(configType) ) {
					this.env.put(sysType, itm);
				} else {
					this.cmdline.put(sysType, itm);
				}
			}
		}
	}

	public Map<String, String> getEnv(String systemId){
		return env.get(systemId);
	}
	
	public Map<String, String> getCmdline(String systemId){
		return cmdline.get(systemId);
	}
	
	
	@Override
	public String toString() {
		return "Config [env=" + env + ", cmdline=" + cmdline + "]";
	}
}
