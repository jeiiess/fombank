package wk.fom.fyl.builder.srcgen.struct.instance.poolimpl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.DbType;
import wk.fom.fyl.builder.srcgen.struct.instance.DbInfo;
import wk.fom.fyl.builder.srcgen.struct.instance.Pool;

public class DBConnectionPool extends Pool {
	public static final String DB_TYPE = "dbType";
	public static final String DB_INFO = "dbInfo";
	
	protected DbType dbType;
	protected Map<String, DbInfo> dbInfo;
	
	public DBConnectionPool() {
		dbInfo = new HashMap<String, DbInfo>();
	}
	
	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		this.dbType = DbType.valueOf(node.get(DBConnectionPool.DB_TYPE).asText());
		ObjectNode dnode = (ObjectNode)node.get(DBConnectionPool.DB_INFO);

		Iterator<String> key = dnode.fieldNames();
		while(key.hasNext()) {
			String nm = key.next();
			dbInfo.put(nm, new DbInfo((ObjectNode)dnode.get(nm)));
		}
	}
	
	public DbType getDbType() {
		return this.dbType;
	}
	
	public DbInfo getDbInfo(String systemId) {
		return this.dbInfo.get(systemId);
	}

	@Override
	public String toString() {
		return "DBConnectionPool [dbType=" + dbType + ", dbInfo=" + dbInfo + ", id=" + id + ", type=" + type + ", min="
				+ min + ", max=" + max + ", libraries=" + libraries + "]";
	}
}
