package wk.fom.fyl.builder.srcgen.struct.instance;

import com.fasterxml.jackson.databind.node.ObjectNode;

public class Library {
	public static final String GROUP_ID = "group_id";
	public static final String ARTIFACT_ID = "artifact_id";
	public static final String VERSION = "version";
	
	private String groupId;
	private String artifactId;
	private String version;
	
	public Library() {
		this.groupId = null;
		this.artifactId = null;
		this.version = null;
	}
	
	public Library(ObjectNode node) {
		this.groupId = node.get(Library.GROUP_ID).asText();
		this.artifactId = node.get(Library.ARTIFACT_ID).asText();
		this.version = node.get(Library.VERSION).asText();
	}
	
	public Library(String groupId, String artifactId, String version) {
		this.groupId = groupId;
		this.artifactId = artifactId;
		this.version = version;
	}

	public String getGroupId() {
		return groupId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public String getVersion() {
		return version;
	}

	@Override
	public String toString() {
		return "Library [groupId=" + groupId + ", artifactId=" + artifactId + ", version=" + version + "]";
	}	
	
}
