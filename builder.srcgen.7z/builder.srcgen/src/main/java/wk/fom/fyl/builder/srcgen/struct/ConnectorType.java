/**
 * 
 */
package wk.fom.fyl.builder.srcgen.struct;

import wk.fom.fyl.builder.srcgen.struct.instance.Connector;

public enum ConnectorType {
	RESTAPI("wk.fom.fyl.builder.srcgen.struct.instance.connectorimpl.RestAPIConnector")
	
	;
	
	private String cName;
	
	ConnectorType(String cName){
		this.cName = cName;
	}
	
	public String getClassName() { return this.cName; }
	
	public Connector getInstance() {
		try {
			return (Connector)Class.forName(cName).newInstance();
		} catch ( Exception ex ) {
			ex.printStackTrace();
			return null;
		}
	}
}
