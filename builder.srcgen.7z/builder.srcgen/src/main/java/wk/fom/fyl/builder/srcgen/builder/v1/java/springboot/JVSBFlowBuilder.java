package wk.fom.fyl.builder.srcgen.builder.v1.java.springboot;

import wk.fom.fyl.builder.srcgen.builder.IFlowBuilder;
import wk.fom.fyl.builder.srcgen.struct.instance.Instance;

public class JVSBFlowBuilder implements IFlowBuilder{

	public void makeFlowSource(Instance instance, String baseDir) {
		// TODO Auto-generated method stub
		System.out.println("IN------instance");		
	}
}
