package wk.fom.fyl.builder.srcgen.struct.model;

import java.util.Iterator;

import com.fasterxml.jackson.databind.node.ObjectNode;

public class Body {
	public static final String DATA = "data";
	public static final String SCHEMA = "schema";
	
	private String data;
	private String schema;
	
	public Body() {
		
	}
	
	public void parse(ObjectNode node) {
		Iterator<String> keys = node.fieldNames();
		while(keys.hasNext()) {
			String key = keys.next();
			if( Body.DATA.equals(key) ) {
				data = node.get(key).asText();
			} else if ( Body.SCHEMA.equals(key) ) {
				schema = node.get(key).asText();
			}
		}
	}
	
	public void set(String data, String schema) {
		this.data = data;
		this.schema = schema;
	}
	
	public String getData() {
		return data;
	}
	
	public String getSchema() {
		return schema;
	}

	@Override
	public String toString() {
		return "Body [data=" + data + ", schema=" + schema + "]";
	}
}
