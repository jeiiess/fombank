package wk.fom.fyl.builder.srcgen.struct.workflow;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import wk.fom.fyl.builder.srcgen.struct.task.Task;

public class Workflow {
	public static final String WORKFLOW_ID = "workflowId";
	public static final String DESCRIPTION = "description";
	public static final String TIMEOUT = "timeout";
	public static final String DATA_SAMPLE = "dataSample";
	public static final String INPUT = "input";
	public static final String OUTPUT = "output";
	public static final String TASKS = "tasks";
	
	public static final String WKF_FILE_TYPE = "YAML";
	
	private String workflowId;
	private String desciption;
	private Long timeout;
	private String inDataSample;
	private String outDataSample;
	private List<Task> tasks;
	
	public Workflow() {
		workflowId = "";
		tasks = new ArrayList<Task>();
	}
	
	public void load(String workflowId, String baseDir) throws Exception {
		this.workflowId = workflowId;
		
		ObjectMapper mapper = null;
		if( WKF_FILE_TYPE.equals("YAML") ) {
			mapper = new ObjectMapper(new YAMLFactory());
		} else {
			mapper = new ObjectMapper(new JsonFactory());
		}
		ObjectNode node = (ObjectNode) mapper.readTree(new File(baseDir + "/" + workflowId + ".yaml") );
		
		parse(node);
	}
	
	public void parse(ObjectNode node) {
		Iterator<String> ids = node.fieldNames();
		while( ids.hasNext() ) {
			String id = ids.next();
			
			if( id.equals(Workflow.DESCRIPTION) ) {
				this.desciption = node.get(id).asText();
			} else if( id.equals(Workflow.TIMEOUT) ) {
				this.timeout = node.get(id).asLong();
			} else if( id.equals(Workflow.DATA_SAMPLE) ) {
				ObjectNode samples = (ObjectNode)node.get(id);
				Iterator<String> tags = samples.fieldNames();
				while( tags.hasNext() ) {
					String tag = tags.next();
					if( tag.equals(Workflow.INPUT) ) {
						this.inDataSample = samples.get(tag).asText();
					} else {
						this.outDataSample = samples.get(tag).asText();
					}
				}
			} else if( id.equals(Workflow.TASKS) ) {
				ArrayNode taskArray = (ArrayNode)node.get(id);
				for( int i=0; i<taskArray.size(); i++) {
					ObjectNode t = (ObjectNode)taskArray.get(i);
					tasks.add(Task.getInstance(t));
				}
			} 
		}
	}

	public String getWorkflowId() {
		return workflowId;
	}

	public String getDesciption() {
		return desciption;
	}

	public Long getTimeout() {
		return timeout;
	}

	public String getInDataSample() {
		return inDataSample;
	}

	public String getOutDataSample() {
		return outDataSample;
	}

	public List<Task> getTasks() {
		return tasks;
	}

	@Override
	public String toString() {
		return "Workflow [workflowId=" + workflowId + ", desciption=" + desciption + ", timeout=" + timeout
				+ ", inDataSample=" + inDataSample + ", outDataSample=" + outDataSample + ", tasks=" + tasks + "]";
	}
}
