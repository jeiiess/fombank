package wk.fom.fyl.builder.srcgen.struct.task;

import com.fasterxml.jackson.databind.node.ObjectNode;

public class EndTask extends Task {

	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub

	}

	@Override
	public String toString() {
		return "EndTask [taskType=" + taskType + ", taskId=" + taskId + ", description=" + description + "]";
	}
	
}
