package wk.fom.fyl.builder.srcgen.struct.task;

import java.util.Iterator;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.model.mediation.Mediation;
import wk.fom.fyl.builder.srcgen.struct.model.response.Response;

public class EndTask extends Task {
	public static final String MEDIATION = "mediation";
	public static final String RESPONSE = "response";

	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		Iterator<String> ids = node.fieldNames();
		while(ids.hasNext()) {
			String id = ids.next();
			if( node.get(id).asText().equals(EndTask.MEDIATION) ) {
				this.mediation = new Mediation();
				this.mediation.parse((ObjectNode)node.get(id));
			} else if( node.get(id).asText().equals(EndTask.RESPONSE) ) {
				this.response = new Response();
				this.response.parse((ObjectNode)node.get(id));
			}
		}
	}

	protected Mediation mediation;
	protected Response response;

	public Mediation getMediation() {
		return mediation;
	}
	public Response getResponse() {
		return response;
	}
	
	@Override
	public String toString() {
		return "EndTask [mediation=" + mediation + ", response=" + response + "]";
	}
}
