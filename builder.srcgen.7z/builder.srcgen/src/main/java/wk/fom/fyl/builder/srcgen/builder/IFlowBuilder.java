package wk.fom.fyl.builder.srcgen.builder;

import wk.fom.fyl.builder.srcgen.struct.instance.Instance;

public interface IFlowBuilder {
	public void makeFlowSource(Instance instance, String baseDir);
}
