package wk.fom.fyl.builder.srcgen.struct.instance.connectorimpl;

import java.util.HashMap;
import java.util.Iterator;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.ConnectorType;
import wk.fom.fyl.builder.srcgen.struct.instance.Connector;

public class RestAPIConnector extends Connector {
	public static final String BASE_URL = "baseUrl";
	
	protected HashMap<String, String> baseUrl;
	
	public RestAPIConnector() {
		baseUrl = new HashMap<String, String>();
	}
	
	public String getBaseUrl(String systemId) {
		return baseUrl.get(systemId);
	}

	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		this.id = node.get(Connector.ID).asText();
		this.connectorType = ConnectorType.valueOf(node.get(Connector.TYPE).asText());
		
		ObjectNode tmp = (ObjectNode)node.get(RestAPIConnector.BASE_URL);
		
		Iterator<String> key = tmp.fieldNames();
		while(key.hasNext()) {
			String nm = key.next();
			baseUrl.put(nm, tmp.get(nm).asText());
		}
	}

	@Override
	public String toString() {
		return "RestAPIConnector [baseUrl=" + baseUrl + ", id=" + id + ", connectorType=" + connectorType + "]";
	}
	
}
