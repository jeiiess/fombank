package wk.fom.fyl.builder.srcgen.struct.model.mediation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.model.util.Tuple;

public class Mediation {
	public static final String HEADER = "header";
	public static final String QUERY_STRING = "queryString";
	public static final String PATH_VARIABLE = "pathVarlable";
	public static final String BODY = "body";
	
	private List<Tuple<String, String>> header;
	private List<Tuple<String, String>> qryString;
	private List<Tuple<String, String>> pathVar;
	private List<Tuple<String, String>> body; 
	
	public Mediation() {
		header = new ArrayList<Tuple<String, String>>();
		qryString = new ArrayList<Tuple<String, String>>();
		pathVar = new ArrayList<Tuple<String, String>>();
		body = new ArrayList<Tuple<String, String>>();
	}
	
	public void parse(ObjectNode node) {
		Iterator<String> params = node.fieldNames();
		List<Tuple<String, String>> tmp = null;
		while( params.hasNext() ) {
			String paramType = params.next();
			if( Mediation.HEADER.equals(paramType) ) {
				tmp = this.header;
			} else if ( Mediation.QUERY_STRING.equals(paramType) ) {
				tmp = this.qryString;
			} else if ( Mediation.PATH_VARIABLE.equals(paramType) ) {
				tmp = this.pathVar;
			} else if ( Mediation.BODY.equals(paramType) ) {
				tmp = this.body;
			} else {
				continue;
			}
			
			ObjectNode subNode = (ObjectNode)node.get(paramType);
			
			Iterator<String> items = subNode.fieldNames();
			while( items.hasNext() ) {
				String itemId = items.next();
				String val = subNode.get(itemId).asText();
				tmp.add(new Tuple<String, String>(itemId, val));
			}
		}
	}

	public List<Tuple<String, String>> getHeader() {
		return header;
	}

	public List<Tuple<String, String>> getQryString() {
		return qryString;
	}

	public List<Tuple<String, String>> getPathVar() {
		return pathVar;
	}

	public List<Tuple<String, String>> getBody() {
		return body;
	}

	@Override
	public String toString() {
		return "Mediation [header=" + header + ", qryString=" + qryString + ", pathVar=" + pathVar + ", body=" + body
				+ "]";
	}
}
