package wk.fom.fyl.builder.srcgen.struct.task;

import java.util.Iterator;

import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.struct.RestMethod;
import wk.fom.fyl.builder.srcgen.struct.model.mediation.Mediation;
import wk.fom.fyl.builder.srcgen.struct.model.param.Parameter;
import wk.fom.fyl.builder.srcgen.struct.model.response.Response;

public class RestApiTask extends Task {
	public static final String CONNECTOR = "connector";
	public static final String URL = "url";
	public static final String METHOD = "method";
	public static final String PARAMETER = "parameter";
	public static final String RESPONSE = "response";
	public static final String MEDIATION = "mediation";
	
	@Override
	public void parse(ObjectNode node) {
		// TODO Auto-generated method stub
		Iterator<String> ids = node.fieldNames();
		while( ids.hasNext() ) {
			String id = ids.next();
			
			if( RestApiTask.CONNECTOR.equals(id) ) {
				this.connector = node.get(id).asText();
			} else if ( RestApiTask.URL.equals(id) ) {
				this.url = node.get(id).asText();
			} else if ( RestApiTask.METHOD.equals(id) ) {
				this.method = RestMethod.valueOf(node.get(id).asText());
			} else if ( RestApiTask.PARAMETER.equals(id) ) {
				this.parameter = new Parameter();
				this.parameter.parse((ObjectNode)node.get(id));
			} else if ( RestApiTask.RESPONSE.equals(id) ) {
				this.response = new Response();
				this.response.parse((ObjectNode)node.get(id));
			} else if ( RestApiTask.MEDIATION.equals(id) ) {
				this.mediation = new Mediation();
				this.mediation.parse((ObjectNode)node.get(id));
			}
		}
	}

	protected String connector;
	protected String url;
	protected RestMethod method;
	protected Parameter parameter;
	protected Mediation mediation;
	protected Response response;
	
	public RestApiTask() {
		this.connector = null;
		this.url = null;
		this.method = null;
		this.parameter = null;
		this.mediation = null;
		this.response = null;
	}

	public String getConnector() {
		return connector;
	}

	public String getUrl() {
		return url;
	}

	public RestMethod getMethod() {
		return method;
	}

	public Parameter getParameter() {
		return parameter;
	}

	public Mediation getMediation() {
		return mediation;
	}

	public Response getResponse() {
		return response;
	}

	@Override
	public String toString() {
		return "RestApiTask [connector=" + connector + ", url=" + url + ", method=" + method + ", parameter="
				+ parameter + ", mediation=" + mediation + ", response=" + response + ", taskType=" + taskType
				+ ", taskId=" + taskId + ", description=" + description + "]";
	}
}
