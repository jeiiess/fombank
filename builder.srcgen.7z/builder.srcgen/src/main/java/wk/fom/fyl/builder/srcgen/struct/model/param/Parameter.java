package wk.fom.fyl.builder.srcgen.struct.model.param;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import wk.fom.fyl.builder.srcgen.props.JOpt;
import wk.fom.fyl.builder.srcgen.struct.model.Body;

public class Parameter {
	public final static String QUERY_STRING = "queryString";
	public final static String PATH_VARIABLE= "pathVarlable";
	public final static String BODY = "body";
	public final static String TYPE = "type";
	public final static String DESCRIPTION = "description";
	public final static String OPTIONAL = "optional";
	
	private List<ParamItem> qryString;
	private List<ParamItem> pathVar;
	private Body body;
	
	public Parameter() {
		qryString = new ArrayList<ParamItem>();
		pathVar = new ArrayList<ParamItem>();
		body = null;
	}
	
	public void parse(ObjectNode node) {
		Iterator<String> paramTypes = node.fieldNames();
		while(paramTypes.hasNext() ) {
			String paramType = paramTypes.next();
			if( Parameter.BODY.equals(paramType) ) {
				this.body = new Body();
				this.body.parse((ObjectNode)node.get(paramType));
			} else {
				ObjectNode sub = (ObjectNode)node.get(paramType);
				
				Iterator<String> keys = sub.fieldNames();
				while(keys.hasNext()) {
					String key = keys.next();
					ObjectNode item = (ObjectNode)sub.get(key);
					
					String tp = item.get(Parameter.TYPE).asText();
					String desc = (String)JOpt.get(item, Parameter.DESCRIPTION, JOpt.STRING);
					String opt = (String)JOpt.get(item, Parameter.OPTIONAL, JOpt.STRING);
					
					if( Parameter.QUERY_STRING.equals(paramType) ) {
						this.qryString.add(new ParamItem(key, desc, tp, opt));
					} else if( Parameter.PATH_VARIABLE.equals(paramType) ) {
						this.pathVar.add(new ParamItem(key, desc, tp, ""));
					}
				}	
			}
		}
	}
	
	public List<ParamItem> getQryString() {
		return this.qryString;
	}
	
	public List<ParamItem> getPathVariable(){
		return this.pathVar;
	}
	
	public Body getBody() {
		return this.body;
	}
	
	@Override
	public String toString() {
		return "Parameter [qryString=" + qryString + ", pathVar=" + pathVar + ", body=" + body + "]";
	}
	
}
