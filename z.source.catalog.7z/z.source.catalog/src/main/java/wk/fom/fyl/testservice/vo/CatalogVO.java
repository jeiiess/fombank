package wk.fom.fyl.testservice.vo;

import java.util.ArrayList;
import java.util.List;

public class CatalogVO {
	private String catalogId;
	private String catalogType;
	private String description;
	private String regUserId;
	private int useCount;
	private List<String> useProjectList;
	
	public String getCatalogId() {
		return catalogId;
	}
	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}
	public String getCatalogType() {
		return catalogType;
	}
	public void setCatalogType(String catalogType) {
		this.catalogType = catalogType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRegUserId() {
		return regUserId;
	}
	public void setRegUserId(String regUserId) {
		this.regUserId = regUserId;
	}
	public int getUseCount() {
		return useCount;
	}
	public void setUseCount(int useCount) {
		this.useCount = useCount;
	}
	public List<String> getUseProjectList() {
		return useProjectList;
	}
	public void setUseProjectList(List<String> useProjectList) {
		this.useProjectList = useProjectList;
	}
	
	public CatalogVO() {
		useCount = 0;
		useProjectList = new ArrayList<String>();
	}
	
	public void addUseProject(String projectId) {
		for(String v : useProjectList) {
			if( projectId.contentEquals(v)) {
				return;
			}
		}
		useCount++;
		useProjectList.add(projectId);
	}
	
	public void deleteUseProject(String projectId) {
		for(int i=0; i<useCount; i++) {
			if( projectId.equals(useProjectList.get(i))){
				useCount--;
				useProjectList.remove(i);
				return;
			}
		}
	}
}
