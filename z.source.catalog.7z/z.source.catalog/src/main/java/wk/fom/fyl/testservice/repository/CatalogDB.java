package wk.fom.fyl.testservice.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import wk.fom.fyl.testservice.vo.CatalogVO;

@Component
public class CatalogDB {
	private Map<String, CatalogVO> db;
	
	public CatalogDB() {
		db = new LinkedHashMap<String, CatalogVO>();
	}
	
	public void put(CatalogVO vo) {
		db.put(vo.getCatalogId(), vo);
	}
	
	public void remove(String catalogId) {
		db.remove(catalogId);
	}
	
	public List<CatalogVO> getAll(){
		 return new ArrayList<CatalogVO>(db.values());
	}
	
	public CatalogVO get(String catalogId) {
		return db.get(catalogId);
	}
	
	public List<CatalogVO> getByType(String catalogType){
		List<CatalogVO> lst = new ArrayList<CatalogVO>();
		for(Entry<String, CatalogVO> itm : db.entrySet() ) {
			if(itm.getValue().getCatalogType().equals(catalogType)) {
				lst.add(itm.getValue());
			}
		}
		return lst;
	}

	public List<CatalogVO> getByRegistUserId(String userId){
		List<CatalogVO> lst = new ArrayList<CatalogVO>();
		for(Entry<String, CatalogVO> itm : db.entrySet() ) {
			if(itm.getValue().getRegUserId().equals(userId)) {
				lst.add(itm.getValue());
			}
		}
		return lst;
	}

	public List<CatalogVO> getByUsedProject(String projectId){
		List<CatalogVO> lst = new ArrayList<CatalogVO>();
		for(Entry<String, CatalogVO> itm : db.entrySet() ) {
			List<String> projects = itm.getValue().getUseProjectList();
			if( projects.contains(projectId)) {
				lst.add(itm.getValue());
			}
		}
		return lst;
	}
}
