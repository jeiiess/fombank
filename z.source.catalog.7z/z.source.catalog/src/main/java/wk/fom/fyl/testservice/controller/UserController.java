package wk.fom.fyl.testservice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import wk.fom.fyl.testservice.repository.IdGenerator;
import wk.fom.fyl.testservice.repository.UserDB;
import wk.fom.fyl.testservice.vo.UserVO;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {
	@Autowired
	private UserDB userDB;
	
	@Autowired
	private IdGenerator idGenerator;
	
	@GetMapping("/")
	public List<UserVO> getUserList(
			@RequestParam("ids") Optional<List<String>> ids,
			@RequestParam("userName") Optional<String> userName){
		if( ids.isPresent() ) {
			List<UserVO> ret = new ArrayList<UserVO>();
			for(String id: ids.get()) {
				ret.add(userDB.get(id));
			}
			return ret;
		} else if( userName.isPresent() ) {
			return userDB.search(userName.get());
		}
		return null;
	}
	
	@PostMapping("/")
	public String addUser(@RequestBody UserVO vo) {
		String id = idGenerator.getUserId();
		vo.setUserId(id);
		userDB.put(vo);
		return id;
	}
	
	@GetMapping("/{userId}")
	public UserVO getUser(@PathVariable("userId") String userId) {
		return userDB.get(userId);
	}
}
