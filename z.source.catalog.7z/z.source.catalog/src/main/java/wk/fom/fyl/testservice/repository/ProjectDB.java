package wk.fom.fyl.testservice.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import wk.fom.fyl.testservice.vo.ProjectVO;

@Component
public class ProjectDB {
	private Map<String, ProjectVO> db;
	
	public ProjectDB() {
		db = new LinkedHashMap<String, ProjectVO>();
	}
	
	public void put(ProjectVO vo) {
		db.put(vo.getProjectId(), vo);
	}
	
	public void remove(String projectId) {
		db.remove(projectId);
	}
	
	public List<ProjectVO> getAll(){
		return new ArrayList<ProjectVO>(db.values());
	}
	
	public ProjectVO get(String projectId) {
		return db.get(projectId);
	}
	
	public List<ProjectVO> getByOwner(String userId){
		List<ProjectVO> lst = new ArrayList<ProjectVO>();
		for(Entry<String, ProjectVO> itm : db.entrySet()) {
			if( itm.getValue().getOwnerId().equals(userId)){
				lst.add(itm.getValue());
			}
		}
		return lst;
	}
	
	public List<ProjectVO> getByName(String projectName){
		List<ProjectVO> lst = new ArrayList<ProjectVO>();
		for(Entry<String, ProjectVO> itm : db.entrySet()) {
			if( itm.getValue().getProjectName().equals(projectName)){
				lst.add(itm.getValue());
			}
		}
		return lst;	
	}
}
