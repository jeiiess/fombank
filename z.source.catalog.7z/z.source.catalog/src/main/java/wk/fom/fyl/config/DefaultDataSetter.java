package wk.fom.fyl.config;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

import wk.fom.fyl.repository.CatalogDB;
import wk.fom.fyl.repository.IdGenerator;
import wk.fom.fyl.repository.ProjectDB;
import wk.fom.fyl.repository.UserDB;
import wk.fom.fyl.vo.CatalogVO;
import wk.fom.fyl.vo.ProjectVO;
import wk.fom.fyl.vo.UserVO;

@Configuration
public class DefaultDataSetter {

	@Autowired
	private CatalogDB catalogDB;
	
	@Autowired
	private ProjectDB projectDB;
	
	@Autowired
	private UserDB userDB;
	
	@Autowired
	private IdGenerator idGenerator;
	
	@Value("${basedata.user}")
	private int userCnt;

	@Value("${basedata.project}")
	private int projectCnt;

	@Value("${basedata.catalog}")
	private int catalogCnt;
	
	@EventListener
	public void onApplicationEvent(ContextRefreshedEvent event) {
		Random rd = new Random(System.nanoTime());
		String[] uids = new String[userCnt];
		for(int i=0; i<userCnt; i++) {
			uids[i] = idGenerator.getUserId();
			UserVO u = new UserVO();
			u.setUserId(uids[i]);
			u.setUserName(uids[i] + "_name");
			u.setEmail(uids[i] + "_email");
			userDB.put(u);
		}
		
		String[] pids = new String[projectCnt];
		for(int i=0; i<projectCnt; i++) {
			pids[i] = idGenerator.getProjectId();
			ProjectVO p = new ProjectVO();
			p.setProjectId(pids[i]);
			p.setProjectName("Project #" + pids[i]);
			p.setBudget(rd.nextLong());
			if( p.getBudget() < 0 )
				p.setBudget(p.getBudget()*-1);
			p.setOwnerId(uids[rd.nextInt(userCnt)]);
			projectDB.put(p);
		}
		
		String[] cids = new String[catalogCnt];
		for(int i=0; i<catalogCnt; i++) {
			cids[i] = idGenerator.getCatalogId();
			CatalogVO c = new CatalogVO();
			c.setCatalogId(cids[i]);
			int r = (rd.nextInt(4));
			switch(r) {
			case 0:
				c.setCatalogType("API");
				break;
			case 1:
				c.setCatalogType("DATA");
				break;
			case 2:
				c.setCatalogType("ASSET");
				break;
			default:
				c.setCatalogType("IMAGE");
				break;
			}
			c.setDescription(cids[i] + " is " + c.getCatalogType() + " catalog.");
			c.setRegUserId(uids[rd.nextInt(userCnt)]);
			for( int x = 0; x<=(rd.nextInt(projectCnt)); x++) {
				c.addUseProject(pids[rd.nextInt(projectCnt)]);
			}
			catalogDB.put(c);
		}
	}
}
