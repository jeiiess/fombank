package wk.fom.fyl.testservice.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import wk.fom.fyl.testservice.vo.UserVO;

@Component
public class UserDB {
	private Map<String, UserVO> db;
	
	public UserDB() {
		db = new LinkedHashMap<String, UserVO>();
	}
	
	public void put(UserVO vo) {
		db.put(vo.getUserId(), vo);
	}
	
	public void remove(String userId) {
		db.remove(userId);
	}
	
	public List<UserVO> getAll(){
		return new ArrayList<UserVO>(db.values());
	}
	
	public UserVO get(String userId) {
		return db.get(userId);
	}
	
	public List<UserVO> search(String name){
		List<UserVO> ret = new ArrayList<UserVO>();
		for(Entry<String, UserVO> e : db.entrySet()) {
			if(e.getValue().getUserName().contains(name)) {
				ret.add(e.getValue());
			}
		}
		return ret;

	}
}
