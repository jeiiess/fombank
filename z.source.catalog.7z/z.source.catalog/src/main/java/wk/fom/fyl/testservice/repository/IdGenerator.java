package wk.fom.fyl.testservice.repository;

import org.springframework.stereotype.Component;

@Component
public class IdGenerator {
	private int catalogId;
	private int userId;
	private int projectId;
	
	public IdGenerator() {
		catalogId = 1;
		userId = 1;
		projectId = 1;
	}
	
	public synchronized  String getCatalogId()  {
		String ret = "c" + pad(catalogId);
		catalogId++;
		return ret;
	}
	
	public synchronized String getProjectId() {
		String ret = "p" + pad(projectId);
		projectId++;
		return ret;
	}
	
	public synchronized String getUserId() {
		String ret = "u" + pad(userId);
		userId++;
		return ret;
	}
	
	
	private String pad(int i) {
		String ret = Integer.toString(i);
		switch(ret.length()) {
		case 0:
			ret = "000";
			break;
		case 1:
			ret = "00" + ret;
			break;
		case 2:
			ret = "0" + ret;
			break;
		default:
			break;
		}
		
		return ret;
	}
}
