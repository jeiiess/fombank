package wk.fom.fyl.testservice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import wk.fom.fyl.testservice.repository.CatalogDB;
import wk.fom.fyl.testservice.repository.IdGenerator;
import wk.fom.fyl.testservice.vo.CatalogVO;

@RestController
@RequestMapping("/api/v1/catalog")
public class CatalogController {
	@Autowired
	private CatalogDB catalogDB;
	
	@Autowired
	private IdGenerator idGenerator;
	
	@PostMapping("/")
	public String addCatalog(@RequestBody CatalogVO vo) {
		String catalogId = idGenerator.getCatalogId();
		vo.setCatalogId(catalogId);
		catalogDB.put(vo);
		return catalogId;
	}
	
	@GetMapping("/")
	public List<CatalogVO> getCatalogList(
			@RequestParam("ids") Optional<List<String>> ids,
			@RequestParam("catalogType") Optional<String> catalogType,
			@RequestParam("regUserId") Optional<String> regUserId,
			@RequestParam("useProjectId") Optional<String> useProjectId
			){
		if(ids.isPresent()) {
			List<CatalogVO> lst = new ArrayList<CatalogVO>();
			for(String id : ids.get()) {
				lst.add(catalogDB.get(id));
			}
			return lst;
		} else if( catalogType.isPresent()) {
			return catalogDB.getByType(catalogType.get());
		} else if( regUserId.isPresent()) {
			return catalogDB.getByRegistUserId(regUserId.get());
		} else if( useProjectId.isPresent()) {
			return catalogDB.getByUsedProject(useProjectId.get());
		} else {
			return null;
		}
	}
	
	@GetMapping("/{catalogId}")
	public CatalogVO getCatalog(@PathVariable("catalogId") String catalogId) {
		return catalogDB.get(catalogId);
	}
}
