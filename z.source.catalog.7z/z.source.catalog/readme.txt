FYL 수행테스트를 위해 구성한 임시 REST API
1. User
  - Data 구조
	{
	  "userId": "u199",
	  "userName": "u199_name",
	  "email": "u199_email"
	}
2. Project
  - Data 구조
	{
	  "budget": 0,
	  "ownerId": "string",
	  "projectId": "string",
	  "projectName": "string"
	}
3. Catalog
  - Data 구조
	{
	  "catalogId": "string",
	  "catalogType": "string",
	  "description": "string",
	  "regUserId": "string",
	  "useCount": 0,
	  "useProjectList": [
	    "string"
	  ]
	}

로 구성되어 있음

APIs 는
http://{app_ip}:{app_port}/swagger-ui.html
참조