package com.example.demo;

import java.util.Random;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloRestController {
	@RequestMapping("/")
	public String index() {
		return "helloworld";
	}
	
	@RequestMapping("/job")
	public String job() {
		Random r = new Random(System.currentTimeMillis());
		long ret = r.nextInt(3000);
		try {
			Thread.sleep(ret);
		} catch ( Exception ex ) {
			ex.printStackTrace();
		}
		
		return new String("I'm sleep for " + ret + " ms");
	}
}
