package com.example.demo;

import java.util.EnumSet;
import java.util.Set;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;

import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;

@Configuration
public class WfConfiguration {
	@EventListener(ApplicationReadyEvent.class)
	public void initAfterStartup() {
		// JsonPath configuration

		com.jayway.jsonpath.Configuration.setDefaults(new com.jayway.jsonpath.Configuration.Defaults() {
			private final JsonProvider jsonProvider = new JacksonJsonNodeJsonProvider();
			private final MappingProvider mappingProvider = new JacksonMappingProvider();
			@Override
			public Set<Option> options() {
				// TODO Auto-generated method stub
				return EnumSet.noneOf(Option.class);
			}
			
			@Override
			public MappingProvider mappingProvider() {
				// TODO Auto-generated method stub
				return mappingProvider;
			}
			
			@Override
			public JsonProvider jsonProvider() {
				// TODO Auto-generated method stub
				return jsonProvider;
			}
		});
	}

}
