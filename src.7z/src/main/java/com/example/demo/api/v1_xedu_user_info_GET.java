package com.example.demo.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ServerUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.jayway.jsonpath.JsonPath;

@RestController
public class v1_xedu_user_info_GET {
	@RequestMapping("/apim/v1/xedu/user/info")
	public String runWorkFlow(String userid) {
		//--- initial job
		System.out.println("Start #0 initialjob");
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode rtNode = mapper.createObjectNode();
		
		rtNode = ServerUtil.makeNode(mapper, rtNode, "workflow");
		
		// make workflow input
		ObjectNode stNode  = null;
		ObjectNode inNode = JsonPath.read(rtNode, "$.workflow.input");
		inNode.put("userid", userid);
		
		//----------------------------------------------------
		// Step #1
		//mediation
		System.out.println("Start #1 Call RESTful API");
		rtNode = ServerUtil.makeNode(mapper, rtNode, "userinfo");
		stNode = (ObjectNode)rtNode.get("userinfo");
		
		try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
			// use httpClient (no need to close it explicitly)
			String url = String.format("http://182.195.31.138:8080/apim/v1/xedu/user/userinfo?userId=%s"
					, ((TextNode)JsonPath.read(rtNode, "$.workflow.input.userid")).asText()
					);
			HttpGet request = new HttpGet(url);
			// add header op
			request.addHeader("version", "v0.1");
			
			HttpResponse response = httpClient.execute(request);
			
			// result handling
			System.out.println(" ->resCode:" + response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode() == 200) {
				BufferedReader br = new BufferedReader(
                        new InputStreamReader((response.getEntity().getContent())));

				String buf;
				String outStr = "";
				while ((buf = br.readLine()) != null) {
					outStr += buf;
				}
				stNode.set("output", mapper.readTree(outStr));
				System.out.println("  res : " + outStr);
			}
		} catch (IOException e) {
		    // handle
			e.printStackTrace();
		}
		//-----------------------------------------------------------------
		
		//-----------------------------------------------------------------
		//  Step #2
		System.out.println("Start #2 Call RESTful API");
		rtNode = ServerUtil.makeNode(mapper, rtNode, "courses");
		stNode = (ObjectNode)rtNode.get("courses");
		inNode = (ObjectNode)stNode.get("input");
		
		// mediation
		inNode.put("userId", ((TextNode)JsonPath.read(rtNode, "$.workflow.input.userid")).asText());

		try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
			// use httpClient (no need to close it explicitly)
			String url = String.format("http://182.195.31.138:8080/apim/v1/xedu/course/usercourse"
					);
			HttpPost request = new HttpPost(url);
			// add header op
			request.addHeader("version", "v0.1");
			request.addHeader("content-type", "application/json");
			
			StringEntity entity = new StringEntity(inNode.toString());
			entity.setContentType("application/json");
		    request.setEntity(entity);
		    
			HttpResponse response = httpClient.execute(request);
			
			// result handling
			System.out.println(" ->resCode:" + response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode() == 200) {
				BufferedReader br = new BufferedReader(
                        new InputStreamReader((response.getEntity().getContent())));

				String buf;
				String outStr = "";
				while ((buf = br.readLine()) != null) {
					outStr += buf;
				}
				stNode.set("output", mapper.readTree(outStr));
				System.out.println("  res : " + outStr);
			}
		} catch (IOException e) {
		    // handle
			e.printStackTrace();
		}
		
		
		//------------------------------------------------------
		// output mediation
		System.out.println("Start #3 Output mediation");
		ObjectNode otNode = JsonPath.read(rtNode, "$.workflow.output");
		otNode.set("user", JsonPath.read(rtNode, "$.userinfo.output"));
		otNode.set("course", JsonPath.read(rtNode, "$.courses.output"));
		
		return otNode.toString();
	}
}
