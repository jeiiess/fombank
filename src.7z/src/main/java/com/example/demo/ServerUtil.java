package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ServerUtil {
	public static Map<String, Object> makeMap(Map<String, Object> parent, String name){
		Map<String, Object> chld = new HashMap<>();
		chld.put("input", new HashMap<String, Object>());
		chld.put("output", new HashMap<String, Object>());
		parent.put(name, chld);
		return parent;
	}
	
	public static ObjectNode makeNode(ObjectMapper mapper, ObjectNode parent, String name) {
		ObjectNode chld = mapper.createObjectNode();
		chld.set("input", mapper.createObjectNode());
		chld.set("output", mapper.createObjectNode());
		parent.set(name, chld);
		return parent;
	}
}
